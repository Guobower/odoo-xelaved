# -*- coding: utf-8 -*-

import project
import invoice
import sale
import survey
import events
import hr
import airport
import inventory
import mass_mailing
import link_tracker
import sale_order_report
import website_video