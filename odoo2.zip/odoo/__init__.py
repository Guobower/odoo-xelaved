# -*- coding: utf-8 -*-

""" Qwarie addons module. """
